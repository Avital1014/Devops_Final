//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'http://localhost:8082/AvitalEladDaniel/'", "snapshot=Action_1.inf");
	truclient_step("2", "ADD", "snapshot=Action_2.inf");
	{
		truclient_step("2.1", "Click on Using Multiple Forms textbox", "snapshot=Action_2.1.inf");
		truclient_step("2.2", "Type 4 in Using Multiple Forms textbox", "snapshot=Action_2.2.inf");
		truclient_step("2.3", "Click on Using Multiple Forms textbox", "snapshot=Action_2.3.inf");
		truclient_step("2.4", "Type 2 in Using Multiple Forms textbox", "snapshot=Action_2.4.inf");
		truclient_step("2.5", "Click on ADD button", "snapshot=Action_2.5.inf");
	}
	truclient_step("3", "SUB", "snapshot=Action_3.inf");
	{
		truclient_step("3.1", "Click on Using Multiple Forms... textbox", "snapshot=Action_3.1.inf");
		truclient_step("3.2", "Type 4 in Using Multiple Forms... textbox", "snapshot=Action_3.2.inf");
		truclient_step("3.3", "Click on Using Multiple Forms textbox", "snapshot=Action_3.3.inf");
		truclient_step("3.4", "Type 5 in Using Multiple Forms textbox", "snapshot=Action_3.4.inf");
		truclient_step("3.5", "Click on SUB button", "snapshot=Action_3.5.inf");
	}
	truclient_step("5", "MUL", "snapshot=Action_5.inf");
	{
		truclient_step("5.1", "Click on Using Multiple Forms... textbox", "snapshot=Action_5.1.inf");
		truclient_step("5.2", "Type 6 in Using Multiple Forms... textbox", "snapshot=Action_5.2.inf");
		truclient_step("5.3", "Click on Using Multiple Forms textbox", "snapshot=Action_5.3.inf");
		truclient_step("5.4", "Type 6 in Using Multiple Forms textbox", "snapshot=Action_5.4.inf");
		truclient_step("5.5", "Click on MUL button", "snapshot=Action_5.5.inf");
	}
	truclient_step("6", "DIV", "snapshot=Action_6.inf");
	{
		truclient_step("6.1", "Click on Using Multiple Forms... textbox", "snapshot=Action_6.1.inf");
		truclient_step("6.2", "Type 12 in Using Multiple Forms... textbox", "snapshot=Action_6.2.inf");
		truclient_step("6.3", "Click on Using Multiple Forms textbox", "snapshot=Action_6.3.inf");
		truclient_step("6.4", "Type 4 in Using Multiple Forms textbox", "snapshot=Action_6.4.inf");
		truclient_step("6.5", "Click on DIV button", "snapshot=Action_6.5.inf");
	}

	return 0;
}
